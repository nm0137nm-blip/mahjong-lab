
#![allow(dead_code, unused_imports)]
mod array; mod consts; mod macros; mod vec_ops; mod rankings;
pub mod algo; pub mod chi_type; pub mod hand; pub mod mjai;
pub mod state; pub mod tile;
use state::PlayerState;
use mjai::Event;
use std::slice;
#[unsafe(no_mangle)]
pub extern "C" fn new_state(seat:u32)->u32 {
    if seat>3{return 0;}
    algo::shanten::ensure_init();
    algo::agari::ensure_init();
    Box::into_raw(Box::new(PlayerState::new(seat as u8))) as u32
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn drop_state(handle:u32){
    if handle!=0 { unsafe { drop(Box::from_raw(handle as *mut PlayerState)); } }
}
#[unsafe(no_mangle)]
pub extern "C" fn alloc_bytes(n:u32)->u32 {
    if n==0 || n>2_000_000{return 0;}
    let mut v=Vec::<u8>::with_capacity(n as usize);
    let ptr=v.as_mut_ptr(); std::mem::forget(v); ptr as u32
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn free_bytes(ptr:u32,n:u32){
    if ptr!=0 && n>0 && n<=2_000_000 {
      unsafe { drop(Vec::<u8>::from_raw_parts(ptr as *mut u8,0,n as usize)); }
    }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn apply_event(handle:u32, ptr:u32,n:u32)->i32{
    if handle==0||ptr==0||n==0||n>8192{return -1;}
    let bytes=unsafe{slice::from_raw_parts(ptr as *const u8,n as usize)};
    let Ok(ev)=serde_json::from_slice::<Event>(bytes) else{return -2;};
    let st=unsafe{&mut*(handle as *mut PlayerState)};
    match st.update(&ev){Ok(c)=>if c.can_act(){1}else{0},Err(_)=>-3}
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn encode_state(handle:u32, obs_dest:u32, mask_dest:u32)->i32{
    if handle==0||obs_dest==0||mask_dest==0{return -1;}
    let st=unsafe{&*(handle as *const PlayerState)};
    let (obs,mask)=st.encode_obs(4,false);
    let Some(flat)=obs.as_slice() else{return -2;};
    if flat.len()!=1012*34 || mask.len()!=46 {return -3;}
    unsafe{
      std::ptr::copy_nonoverlapping(flat.as_ptr(), obs_dest as *mut f32,flat.len());
      for (i,&v) in mask.iter().enumerate() {
        *((mask_dest as *mut u8).add(i)) = u8::from(v);
      }
    }
    0
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn clone_state(handle:u32)->u32{
    if handle==0{return 0;}
    let st=unsafe{&*(handle as *const PlayerState)};
    Box::into_raw(Box::new(st.clone())) as u32
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn encode_kan_state(handle:u32,obs_dest:u32,mask_dest:u32)->i32{
    if handle==0||obs_dest==0||mask_dest==0{return -1;}
    let st=unsafe{&*(handle as *const PlayerState)};
    let (obs,mask)=st.encode_obs(4,true);
    let Some(flat)=obs.as_slice() else{return -2;};
    if flat.len()!=1012*34||mask.len()!=46{return -3;}
    unsafe{
      std::ptr::copy_nonoverlapping(flat.as_ptr(),obs_dest as *mut f32,flat.len());
      for(i,&v) in mask.iter().enumerate(){*((mask_dest as *mut u8).add(i))=u8::from(v);}
    }
    0
}
